// view comment V3 default config.js

window.CONFIG_DEFAULT = {
  DISPLAY_MODE: 'stack',
  STACK_X: 20,
  STACK_EDGE: 20,
  STACK_SCALE: 100,
  SUPPORT_BOARD_ENABLED: false,
  SUPPORT_BOARD_SUPERCHAT: true,
  SUPPORT_BOARD_SUPERSTICKER: false,
  SUPPORT_BOARD_JEWEL: false,
  SUPPORT_BOARD_MEMBERSHIP_GIFT: false,
  SUPPORT_BOARD_GIFT_RECEIVED: false,
  SUPPORT_BOARD_OTHER: false,
  SUPPORT_BOARD_WIDTH: 420,
  UNDERBAR_MODE: 'ticker',
  UNDERBAR_LANES: 1,
  UNDERBAR_LANE_MODE: 'available',
  UNDERBAR_LANE_GAP: 20,
  UNDERBAR_SLIDE_MS: 450,
  UNDERBAR_EXIT_CARDS: 2,
  UNDERBAR_DIRECTION: 'rtl',
  UNDERBAR_SPEED: 140,
  UNDERBAR_WIDTH: 600,
  UNDERBAR_SCALE: 100,
  UNDERBAR_BOTTOM: 28,
  UNDERBAR_GAP: 60,
  UNDERBAR_QUEUE: 20,
  POPUP_PLACEMENT: 'random',
  POPUP_X: 50,
  POPUP_Y: 50,
  POPUP_SPREAD_X: 8,
  POPUP_SPREAD_Y: 6,
  POPUP_WIDTH: 420,
  POPUP_SCALE: 100,
  POPUP_DURATION: 6,
  POPUP_MAX_ITEMS: 12,
  // 同梱演出。位置・サイズ比率・位相はコメントごとに保持する。
  COMMENT_EFFECT: 'heart',
  STAR_TARGET: 'support-membership',
  STAR_DIRECTION: 'down-right',
  STAR_COUNT: 12,
  STAR_COLORS: '#fff7ad,#ffd166,#7dd3fc',
  STAR_SIZE_MIN: 14,
  STAR_SIZE_MAX: 28,
  STAR_DURATION_MIN: 1.8,
  STAR_DURATION_MAX: 3.2,
  HEART_TARGET: 'support-membership',
  HEART_COUNT: 6,
  HEART_SIZE: 32,
  HEART_COLOR: '#ff416c',
  HEART_DURATION: 2.5,
  FLASH_TARGET: 'support-membership',
  FLASH_MODE: 'shimmer',
  FLASH_COLOR: '#ffd166',
  FLASH_COLOR_MODE: 'fixed',
  FLASH_STRENGTH: 0.75,
  FLASH_DURATION: 3,
  // 表示設定
  MAX_ITEMS: 8,               // 最大表示件数
  MAX_WIDTH: "900px",         // 横幅 ("100%", "600px" など)
  STACK_DIRECTION: "up",      // 積み上げ方向 ("up" or "down")
  ITEM_GAP_PX: 4,            // コメント間の隙間

  // 要素の表示切り替え
  SHOW_ICON: true,            // アイコンを表示するか
  SHOW_NAME: true,            // 名前を表示するか
  SHOW_BADGES: true,          // バッジを表示するか
  SHOW_USER_FLAGS: true,      // OWNER/MODバッジを表示するか
  COMMENT_TRANSLATION_MODE: "original", // "original" 元文 / "translated" 翻訳 / "both" 両方
  MAX_COMMENT_UNITS: 0,       // コメント本文の任意上限 (0で無制限)

  // イベント本文表示
  SHOW_EVENT_MESSAGES: true,                 // イベント本文を表示するか
  SHOW_EVENT_MESSAGE_SUPERCHAT: true,        // スーパーチャット本文を表示
  SHOW_EVENT_MESSAGE_SUPERSTICKER: true,     // スーパーステッカー本文を表示
  SHOW_EVENT_MESSAGE_MEMBERSHIP_COMMENT: true, // メンバーシップ継続・コメント本文を表示
  SHOW_EVENT_MESSAGE_MEMBER_JOIN: true,      // メンバーシップ加入案内文を表示
  SHOW_EVENT_MESSAGE_MEMBERSHIP_GIFT: true,  // メンバーシップギフト送信本文を表示
  SHOW_EVENT_MESSAGE_GIFT_RECEIVED: true,   // メンバーシップギフト受け取り本文を表示

  // フォント・サイズ
  FONT_FAMILY: `"M PLUS 1p", "Noto Sans JP", sans-serif`,
  FONT_SIZE: 24,              // 基本文字サイズ (px)
  META_SCALE: 0.8,            // 名前・バッジのサイズ倍率

  // 演出・タイマー
  AUTO_HIDE_MS: 0,        // 自動非表示までの時間 (0で永続表示)
  FADE_IN_MS: 300,            // 入場アニメーション時間
  FADE_OUT_MS: 500,           // 退場アニメーション時間

  // ギフト・スパチャ設定
  GIFT_BG_OPACITY: 0.9,       // ギフトの背景透明度 (0.0～1.0)
  GIFT_BORDER_OPACITY: 1.0,   // ギフトの枠線透明度 (0.0～1.0)
  MEMBER_BG_OPACITY: 0.9,     // メンバー系の背景透明度 (0.0～1.0)
  MEMBER_BORDER_OPACITY: 1.0, // メンバー系の枠線透明度 (0.0～1.0)

  // カラー・スタイル詳細設定
  BG_COLOR: "#000000",             // コメント枠の背景色
  BG_OPACITY: 0.45,                 // コメント枠の背景透明度 (0.0～1.0)
  BG_GLASS: "rgba(0, 0, 0, 0.45)", // 旧設定との互換用
  BG_BLUR: "12px",                // 背景のぼかし強度
  BASE_BORDER_COLOR: "#ffffff",   // 通常コメント枠線の色
  BASE_BORDER_OPACITY: 0.15,       // 通常コメント枠線の濃さ (0.0～1.0)
  BASE_BORDER_WIDTH: 1,            // 通常コメント枠線の太さ (px)
  SYSTEM_BORDER_OPACITY: 0.35,     // 固定コメント枠線の濃さ (0.0～1.0)
  TEXT_MAIN: "#ffffff",           // メイン文字色
  TEXT_NAME: "#eeeeee",           // 名前の文字色
  ACCENT_COLOR: "#ffd700",        // アクセントカラー（ギフト等のデフォルト色）
  SHADOW_SOFT: "0 4px 12px rgba(0, 0, 0, 0.3)", // 影の設定

  // デバッグ
  DEBUG: false
};
