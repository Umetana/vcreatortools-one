(function () {
  'use strict';

  const runtime = window.VCT_CONFIG_RUNTIME;
  const schema = window.VCT_SETTINGS_SCHEMA;
  if (!runtime || !schema) return;

  let draft = { ...runtime.effective };
  let root;
  let controls;
  let sourceText;
  let statusText;
  let colorPicker;
  let colorPickerMount;
  let reloadConfirmation;
  let placement;
  const panelSideKey = `${runtime.storageKey}.panel-side`;
  let panelSide = 'right';
  let panelCollapsed = false;

  try {
    panelSide = window.localStorage.getItem(panelSideKey) === 'left' ? 'left' : 'right';
  } catch (_) {}

  const setStatus = (message, isError = false) => {
    statusText.textContent = message || '';
    statusText.classList.toggle('is-error', isError);
  };

  const fieldKeys = () => Object.values(schema).flatMap(section => Object.keys(section.fields));

  const normalizedConfig = (source) => {
    const result = {};
    for (const key of fieldKeys()) {
      if (Object.prototype.hasOwnProperty.call(source || {}, key)) result[key] = source[key];
    }
    return result;
  };

  const updateSource = () => {
    const labels = {
      localStorage: 'ローカル設定を適用中',
      'config.js': 'config.js を適用中',
      'config_default.js': '初期設定を適用中'
    };
    const profile = runtime.profileId === 'default' ? '標準' : runtime.profileId;
    sourceText.textContent = `${labels[runtime.source] || runtime.source} ｜ プロファイル: ${profile}${runtime.profileWarning ? ' ｜ ' + runtime.profileWarning : ''}`;
  };

  const normalizeHexColor = (value) => {
    const text = String(value || '').trim();
    if (/^#[0-9a-f]{6}$/i.test(text)) return text;
    if (/^[0-9a-f]{6}$/i.test(text)) return `#${text}`;
    return text;
  };

  const makeInput = (key, field) => {
    const wrap = document.createElement('label');
    wrap.className = 'vct-settings-field';
    const title = document.createElement('span');
    title.textContent = field.label;
    wrap.appendChild(title);

    const row = document.createElement('span');
    row.className = 'vct-settings-input-row';
    const input = document.createElement('input');
    input.dataset.configKey = key;

    if (field.type === 'checkbox') {
      input.type = 'checkbox';
      input.checked = !!draft[key];
    } else if (field.type === 'color') {
      const value = draft[key] ?? '';
      const picker = document.createElement('input');
      const text = document.createElement('input');
      const colorValue = normalizeHexColor(value);
      picker.type = 'color';
      picker.value = /^#[0-9a-f]{6}$/i.test(colorValue) ? colorValue : '#ffffff';
      picker.className = 'vct-settings-color-picker';
      text.type = 'text';
      text.value = value;
      text.dataset.configKey = key;
      text.className = 'vct-settings-color-text';
      if (colorPicker) {
        colorPicker.attach(text, { label: field.label });
      }
      picker.addEventListener('input', () => {
        text.value = picker.value;
        text.dispatchEvent(new Event('input', { bubbles: true }));
      });
      text.addEventListener('input', () => {
        const normalized = normalizeHexColor(text.value);
        if (/^#[0-9a-f]{6}$/i.test(normalized)) {
          picker.value = normalized;
        }
      });
      text.addEventListener('blur', () => {
        text.value = normalizeHexColor(text.value);
      });
      row.append(picker, text);
      wrap.appendChild(row);
      return wrap;
    } else if (field.type === 'range') {
      input.type = 'range';
      input.min = field.min;
      input.max = field.max;
      input.step = field.step;
      input.value = draft[key];
      const number = document.createElement('input');
      number.type = 'number';
      number.className = 'vct-settings-range-number';
      number.dataset.rangeKey = key;
      number.setAttribute('aria-label', field.label + '（数値入力）');
      input.setAttribute('aria-label', field.label + '（スライダー）');
      number.min = input.min; number.max = input.max; number.step = input.step;
      number.value = input.value;
      const commitNumber = () => {
        // range自身の範囲・刻みへの補正を利用し、小数の誤差も揃える。
        if (number.value.trim() !== '' && Number.isFinite(number.valueAsNumber)) input.value = number.value;
        number.value = input.value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
      };
      // 入力途中の空欄や小数は設定へ流さず、確定時に反映する。
      number.addEventListener('input', event => event.stopPropagation());
      number.addEventListener('change', commitNumber);
      number.addEventListener('blur', commitNumber);
      number.addEventListener('keydown', event => {
        if (event.key === 'Enter') { event.preventDefault(); commitNumber(); }
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
          event.preventDefault();
          if (number.value.trim() !== '' && Number.isFinite(number.valueAsNumber)) input.value = number.value;
          if (event.key === 'ArrowUp') input.stepUp(); else input.stepDown();
          number.value = input.value;
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      });
      input.addEventListener('input', () => { number.value = input.value; });
      row.append(input, number);
      wrap.appendChild(row);
      return wrap;
    } else if (field.type === 'select') {
      const select = document.createElement('select');
      select.dataset.configKey = key;
      for (const optionValue of field.options) {
        const option = document.createElement('option');
        option.value = optionValue;
        option.textContent = field.labels?.[optionValue] || optionValue;
        option.selected = draft[key] === optionValue;
        select.appendChild(option);
      }
      row.appendChild(select);
      wrap.appendChild(row);
      return wrap;
    } else {
      input.type = field.type === 'color' && /^#[0-9a-f]{6}$/i.test(draft[key] || '') ? 'color' : field.type;
      input.value = draft[key] ?? '';
      if (['MAX_WIDTH', 'BG_BLUR'].includes(key)) {
        const commitLength = () => {
          if (root.hidden) return;
          input.value = runtime.normalizeLength(input.value);
          input.dispatchEvent(new Event('input', { bubbles: true }));
        };
        input.addEventListener('blur', commitLength);
        input.addEventListener('keydown', event => {
          if (event.key === 'Enter') { event.preventDefault(); commitLength(); }
        });
      }
    }

    row.appendChild(input);
    wrap.appendChild(row);
    return wrap;
  };

  const updateEffectVisibility = () => {
    controls.querySelectorAll('[data-effect]').forEach(group => { group.hidden = group.dataset.effect !== draft.COMMENT_EFFECT; });
    controls.querySelectorAll('[data-display]').forEach(group => { group.hidden = group.dataset.display !== draft.DISPLAY_MODE; });
  };
  const render = () => {
    controls.replaceChildren();
    for (const section of Object.values(schema)) {
      const group = document.createElement('section');
      group.className = 'vct-settings-section';
      if (section.effect) group.dataset.effect = section.effect;
      if (section.display) group.dataset.display = section.display;
      group.hidden = (!!section.effect && section.effect !== draft.COMMENT_EFFECT) || (!!section.display && section.display !== draft.DISPLAY_MODE);
      const heading = document.createElement('h3');
      heading.textContent = section.title;
      group.appendChild(heading);
      for (const [key, field] of Object.entries(section.fields)) {
        group.appendChild(makeInput(key, field));
      }
      if (Object.prototype.hasOwnProperty.call(section.fields, 'SUPPORT_BOARD_ENABLED')) {
        // OBSの対話でも操作できるよう、標準confirmではなくパネル内で確認する。
        const confirmation = document.createElement('div');
        confirmation.className = 'vct-board-clear-confirm';
        confirmation.hidden = true;
        const message = document.createElement('p');
        message.textContent = '配置カードと保存内容をすべて消去します。通常ログと設定は残ります。この操作は取り消せません。';
        const trigger = createButton('配置したギフトカードを全消去', 'is-danger', () => {
          confirmation.hidden = false;
          trigger.hidden = true;
          cancel.focus();
        });
        const resetConfirmation = () => {
          confirmation.hidden = true;
          trigger.hidden = false;
          trigger.focus();
        };
        const cancel = createButton('キャンセル', 'is-secondary', resetConfirmation);
        const confirm = createButton('全消去を実行', 'is-danger', () => {
          window.dispatchEvent(new Event('vct-board-clear'));
          const error = window.VCT_BOARD_STORE?.error;
          setStatus(error || '配置カードと保存内容を全消去しました。', !!error);
          resetConfirmation();
        });
        confirmation.append(message, cancel, confirm);
        group.append(trigger, confirmation);
      }
      controls.appendChild(group);
    }
    colorPicker?.refresh();
  };

  const collect = () => {
    const next = { ...draft };
    controls.querySelectorAll('[data-config-key]').forEach(input => {
      const key = input.dataset.configKey;
      if (input.type === 'checkbox') next[key] = input.checked;
      else if (input.type === 'number' || input.type === 'range') next[key] = Number(input.value);
      else if (input.classList.contains('vct-settings-color-text')) next[key] = normalizeHexColor(input.value);
      else if (['MAX_WIDTH', 'BG_BLUR'].includes(key)) next[key] = runtime.normalizeLength(input.value);
      else next[key] = input.value;
    });
    return next;
  };

  const emitPreview = (nextConfig) => {
    placement?.setConfig(nextConfig || collect());
    window.dispatchEvent(new CustomEvent('vct-settings-preview', {
      detail: { ...(nextConfig || collect()) }
    }));
  };

  const loadDraft = (source, message) => {
    draft = { ...runtime.defaults, ...normalizedConfig(source) };
    render();
    emitPreview(draft);
    setStatus(message);
  };

  const parseConfigFile = (text) => window.VCT_PARSE_CONFIG(text);

  const createButton = (label, className, handler) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    button.textContent = label;
    button.addEventListener('click', handler);
    return button;
  };

  const updatePanelUi = () => {
    if (!root) return;
    root.classList.toggle('is-left', panelSide === 'left');
    root.classList.toggle('is-collapsed', panelCollapsed);
    const sideButton = root.querySelector('.vct-settings-side-toggle');
    const collapseButton = root.querySelector('.vct-settings-collapse-toggle');
    if (sideButton) {
      sideButton.title = panelSide === 'right' ? '設定パネルを左へ移動' : '設定パネルを右へ移動';
      sideButton.setAttribute('aria-label', sideButton.title);
    }
    if (collapseButton) {
      collapseButton.textContent = panelCollapsed ? '▣' : '—';
      collapseButton.title = panelCollapsed ? '設定パネルを展開' : '設定パネルを折りたたんで確認';
      collapseButton.setAttribute('aria-label', collapseButton.title);
    }
  };

  const togglePanelSide = () => {
    panelSide = panelSide === 'right' ? 'left' : 'right';
    try { window.localStorage.setItem(panelSideKey, panelSide); } catch (_) {}
    updatePanelUi();
  };

  const togglePanelCollapsed = () => {
    panelCollapsed = !panelCollapsed;
    updatePanelUi();
  };

  const build = () => {
    root = document.createElement('div');
    root.id = 'vct-settings-root';
    root.hidden = true;

    const backdrop = document.createElement('button');
    backdrop.type = 'button';
    backdrop.className = 'vct-settings-backdrop';
    backdrop.setAttribute('aria-label', '設定を閉じる');
    backdrop.addEventListener('click', close);

    const panel = document.createElement('aside');
    panel.className = 'vct-settings-panel';
    panel.setAttribute('aria-label', '表示設定');

    const header = document.createElement('header');
    const headingWrap = document.createElement('div');
    headingWrap.className = 'vct-settings-heading';
    const heading = document.createElement('h2');
    heading.textContent = '表示設定';
    sourceText = document.createElement('p');
    sourceText.className = 'vct-settings-source';
    headingWrap.append(heading, sourceText);
    const closeButton = createButton('\u00d7', 'vct-settings-close', close);
    closeButton.title = '閉じる';
    const headerActions = document.createElement('div');
    headerActions.className = 'vct-settings-header-actions';
    const sideButton = createButton('⇆', 'vct-settings-side-toggle', togglePanelSide);
    const collapseButton = createButton('—', 'vct-settings-collapse-toggle', togglePanelCollapsed);
    headerActions.append(sideButton, collapseButton, closeButton);
    header.append(headingWrap, headerActions);

    controls = document.createElement('div');
    controls.className = 'vct-settings-controls';
    controls.addEventListener('input', () => {
      if (root.hidden) return;
      draft = collect();
      updateEffectVisibility();
      emitPreview(draft);
      setStatus('プレビュー中です。保存するまで確定されません。');
    });
    controls.addEventListener('change', () => {
      if (root.hidden) return;
      draft = collect();
      updateEffectVisibility();
      emitPreview(draft);
    });

    const tools = document.createElement('div');
    tools.className = 'vct-settings-tools';
    tools.append(
      createButton('変更を保存', 'is-primary', () => saveChanges()),
      createButton('再読み込み', 'is-secondary', () => {
        if (isDirty()) reloadConfirmation.hidden = false;
        else window.location.reload();
      }),
      createButton('現在の設定', 'is-secondary', () => loadDraft(runtime.effective, '現在の適用値を読み込みました。')),
      createButton('config.js', 'is-secondary', () => loadDraft(runtime.baseline, 'config.js の値を読み込みました。')),
      createButton('初期設定', 'is-secondary', () => loadDraft(runtime.defaults, '初期設定を読み込みました。')),
      createButton('背景・枠を透明', 'is-secondary', () => loadDraft({
        ...collect(),
        BG_OPACITY: 0,
        BG_GLASS: 'rgba(0, 0, 0, 0)',
        BG_BLUR: '0px',
        BASE_BORDER_OPACITY: 0,
        GIFT_BG_OPACITY: 0,
        GIFT_BORDER_OPACITY: 0,
        MEMBER_BG_OPACITY: 0,
        MEMBER_BORDER_OPACITY: 0,
        SYSTEM_BORDER_OPACITY: 0,
        SHADOW_SOFT: 'none'
      }, '背景・枠線・影を透明化してプレビューしています。'))
    );

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.js,text/javascript';
    fileInput.hidden = true;
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files?.[0];
      if (!file) return;
      try {
        loadDraft(parseConfigFile(await file.text()), `${file.name} を読み込み、プレビューしています。保存するまで確定されません。`);
      } catch (error) {
        setStatus(`読み込みに失敗しました: ${error.message}`, true);
      } finally {
        fileInput.value = '';
      }
    });
    tools.append(createButton('ファイルから読込', 'is-secondary', () => fileInput.click()), fileInput);

    reloadConfirmation = document.createElement('div');
    reloadConfirmation.className = 'vct-settings-tools';
    reloadConfirmation.hidden = true;
    const reloadMessage = document.createElement('p');
    reloadMessage.textContent = '未保存の変更を破棄して再読み込みしますか？';
    reloadConfirmation.append(reloadMessage,
      createButton('破棄して再読み込み', 'is-danger', () => window.location.reload()),
      createButton('取消', 'is-secondary', () => { reloadConfirmation.hidden = true; }));
    const previewTools = document.createElement('div');
    previewTools.className = 'vct-settings-tools';
    const placementButton = createButton('マウス調整を開始', 'is-secondary', () => placement.toggle());
    previewTools.append(placementButton);
    for (const [kind, label] of [['normal', '通常を試す'], ['support', '支援を試す'], ['membership', 'メンバーを試す'], ['clear', 'テスト表示を消去']]) {
      previewTools.append(createButton(label, 'is-secondary', () => window.dispatchEvent(new CustomEvent('vct-test-comment', { detail: kind }))));
    }

    colorPickerMount = document.createElement('div');
    colorPickerMount.className = 'vct-settings-inline-color-picker';
    if (window.VCTInlineColorPicker?.create) {
      colorPicker = window.VCTInlineColorPicker.create({ mount: colorPickerMount });
    }

    statusText = document.createElement('p');
    statusText.className = 'vct-settings-status';

    const footer = document.createElement('footer');
    footer.append(
      createButton('ローカル設定を削除', 'is-danger', () => {
        runtime.clearLocal();
        runtime.broadcastReload?.('settings-cleared');
        window.location.reload();
      }),
      createButton('保存して再読み込み', 'is-primary', () => {
        try {
          runtime.commitLocal(collect());
          runtime.broadcastReload?.('settings-saved');
          window.location.reload();
        } catch (error) {
          setStatus('ローカル設定を保存できませんでした。', true);
        }
      })
    );

    panel.append(header, tools, reloadConfirmation, previewTools, colorPickerMount, controls, statusText, footer);
    root.append(backdrop, panel);
    placement = window.VCT_DISPLAY_PLACEMENT.create({
      mount: root,
      onState({ enabled, supported }) {
        placementButton.disabled = !supported;
        placementButton.textContent = supported ? (enabled ? 'マウス調整を終了' : 'マウス調整を開始') : 'マウス調整（未対応）';
        placementButton.setAttribute('aria-pressed', String(enabled));
      },
      onChange(patch) {
        if (root.hidden) return;
        draft = { ...collect(), ...patch };
        // ドラッグ中の要素を作り直さず、数値欄とスライダーを一緒に更新する。
        for (const [key, value] of Object.entries(patch)) {
          const input = controls.querySelector(`[data-config-key="${key}"]`);
          const number = controls.querySelector(`[data-range-key="${key}"]`);
          if (input) input.value = value;
          if (number) number.value = value;
        }
        emitPreview(draft);
        setStatus('配置をプレビュー中です。「変更を保存」で確定できます。');
      }
    });
    document.body.appendChild(root);
    updateSource();
    render();
    updatePanelUi();
  };

  function open() {
    if (!root) build();
    draft = { ...runtime.effective };
    panelCollapsed = false;
    reloadConfirmation.hidden = true;
    updateSource();
    render();
    setStatus('設定変更は画面へ一時反映されます。保存するまで確定されません。');
    placement.setConfig(draft);
    placement.setEnabled(false);
    root.hidden = false;
    updatePanelUi();
    document.documentElement.classList.add('vct-settings-open');
  }

  function close() {
    if (!root) return;
    placement.setEnabled(false);
    root.hidden = true;
    window.dispatchEvent(new CustomEvent('vct-test-comment', { detail: 'clear' }));
    window.dispatchEvent(new CustomEvent('vct-settings-reset-preview'));
    draft = { ...runtime.effective };
    document.documentElement.classList.remove('vct-settings-open');
    document.getElementById('vct-settings-launcher')?.blur();
  }

  const isDirty = () => !!root && !root.hidden && Object.entries(collect()).some(([key, value]) => value !== runtime.effective[key]);
  function saveChanges() {
    try {
      runtime.commitLocal(collect());
      draft = { ...runtime.effective };
      reloadConfirmation.hidden = true;
      updateSource();
      setStatus('変更を保存しました。再読み込みはしていません。');
    } catch (error) { setStatus('ローカル設定を保存できませんでした。', true); }
  }
  window.VCT_SETTINGS_PANEL = Object.freeze({ open, close, isDirty });
})();
